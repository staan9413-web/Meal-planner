import { getStore } from '@netlify/blobs'
import type { Config, Context } from '@netlify/functions'

const MAX_BYTES = 1_000_000

export default async (req: Request, context: Context) => {
  const code = (context.params.code || '').toLowerCase().replace(/[^a-z0-9]/g, '')
  if (!code || code.length > 64) {
    return Response.json({ error: 'Invalid household code' }, { status: 400 })
  }

  const store = getStore({ name: 'household-sync', consistency: 'strong' })

  if (req.method === 'GET') {
    // Unknown codes return null (not 404) so the client can show "no saved data"
    const data = await store.get(code, { type: 'json' })
    return Response.json(data ?? null, { headers: { 'Cache-Control': 'no-store' } })
  }

  if (req.method === 'PUT') {
    const body = await req.text()
    if (body.length > MAX_BYTES) {
      return Response.json({ error: 'Payload too large' }, { status: 413 })
    }
    let data: unknown
    try {
      data = JSON.parse(body)
    } catch {
      return Response.json({ error: 'Invalid JSON' }, { status: 400 })
    }
    if (!data || typeof data !== 'object' || !('meals' in data)) {
      return Response.json({ error: 'Invalid app state' }, { status: 400 })
    }
    await store.setJSON(code, data)
    return Response.json({ ok: true })
  }

  return new Response('Method not allowed', { status: 405 })
}

export const config: Config = {
  path: '/api/sync/:code',
  method: ['GET', 'PUT'],
}
