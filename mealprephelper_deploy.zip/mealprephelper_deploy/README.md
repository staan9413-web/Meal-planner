# Meal Prep Helper – Netlify deploy (with Cloud Sync / Blobs)

## What’s included
- `index.html` – app (incl. stock qty slider 0–10)
- `netlify/functions/sync.mts` – Netlify Blobs sync API at `/api/sync/:code`
- `package.json` – `@netlify/blobs` dependency
- `netlify.toml` – functions directory config

## Deploy (recommended: Netlify CLI)

```bash
cd mealprephelper_deploy
npm install
npx netlify login
npx netlify deploy --prod
```

Or link a Git repo containing this folder in the Netlify UI and deploy.

## After deploy – test sync

```bash
curl -i -X PUT "https://YOUR-SITE.netlify.app/api/sync/testhome123" \
  -H "Content-Type: application/json" \
  -d '{"meals":{"babyLunch":[]},"categories":[],"stockList":[],"updatedAt":"2026-10-23T00:00:00Z"}'
```

Expect HTTP 200 and `{"ok":true}`.

In the app: Cloud Sync → enter a household code → Push / Pull.

## Note
Drag-and-drop of only `index.html` will NOT deploy the function. Use CLI or Git so `netlify/functions` is built.
